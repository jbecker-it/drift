import { useState, useEffect, useRef, useCallback } from 'react';
import {
  saveEntry, saveDraft, finalizeDraft, getRecentEntries, logMood, updateEntry, deleteEntry, db,
  awardReward,
  getTodaysTasks, addTask, toggleTask, deleteTask, getTodayTasksSummary,
  getEntrySummaries, extractTasksFromTags, getTaskNudgeSummary, type Task,
  type JournalEntry,
} from '../db';
import { streamChat } from '../ai/openrouter';
import { getReflectionPrompt, buildMessages, REQUEST_CONFIG } from '../ai/prompts';
import { tagEntry } from '../ai/tagging';
import { shouldRefreshContext, refreshContextMemory, getContextMemoryPrompt } from '../ai/context';
import { getModel, getApiKey } from '../db';

const MOODS = [
  { value: 1, emoji: '😞', label: 'Struggling' },
  { value: 2, emoji: '😐', label: 'Low' },
  { value: 3, emoji: '🙂', label: 'Okay' },
  { value: 4, emoji: '😊', label: 'Good' },
  { value: 5, emoji: '🤩', label: 'Great' },
];

// ─── Award achievements after a successful save ──────
async function checkAndAwardAchievements(entryCount: number, wordCount: number) {
  if (entryCount === 1) {
    await awardReward('insight', '🌱 First Entry', 'You just wrote your first entry');
  }
  if (entryCount >= 50) {
    await awardReward('wordcount', '🧠 Brain Dump Champion', '50+ entries and counting');
  }
  if (wordCount >= 1000) {
    await awardReward('deepthought', '💭 Deep Thinker', 'Written over 1,000 words total');
  }
}

export default function JournalPage() {
  const [body, setBody] = useState('');
  const [mood, setMood] = useState<number | undefined>();
  const [saving, setSaving] = useState(false);
  const [wordCount, setWordCount] = useState(0);
  const [recentEntries, setRecentEntries] = useState<JournalEntry[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [expandedEntry, setExpandedEntry] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  // ─── Today's tasks ─────────────────────────────────
  const [tasks, setTasks] = useState<Task[]>([]);
  const [newTaskText, setNewTaskText] = useState('');

  // ─── Post-save reflection state ────────────────────
  const [activeEntryId, setActiveEntryId] = useState<string | null>(null);
  const [reflection, setReflection] = useState('');
  const [reflecting, setReflecting] = useState(false);
  const [showContinue, setShowContinue] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const autoSaveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const draftIdRef = useRef<string | null>(null);
  // Separate abort controllers for each operation to avoid interference (#9)
  const reflectAbortRef = useRef<AbortController | null>(null);
  const topicAbortRef = useRef<AbortController | null>(null);
  const savedReflectAbortRef = useRef<AbortController | null>(null);
  // Auto-save serialization — prevents duplicate drafts from concurrent timers
  const autoSaveChain = useRef<Promise<void>>(Promise.resolve());
  const isSavingRef = useRef(false);
  // Session token — incremented on Done/new entry to invalidate stale auto-save callbacks
  const draftSessionRef = useRef(0);

  // Cleanup: abort all in-flight streams when component unmounts
  useEffect(() => {
    return () => {
      reflectAbortRef.current?.abort();
      topicAbortRef.current?.abort();
      savedReflectAbortRef.current?.abort();
    };
  }, []);

  const loadEntries = useCallback(async () => {
    const entries = await getRecentEntries(10);
    setRecentEntries(entries);
  }, []);

  const loadTasks = useCallback(async () => {
    const today = await getTodaysTasks();
    setTasks([...today].sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      return a.createdAt.localeCompare(b.createdAt);
    }));
  }, []);

  useEffect(() => { loadEntries(); loadTasks(); }, [loadEntries, loadTasks]);

  // Recover any existing draft on mount
  useEffect(() => {
    if (activeEntryId) return; // Don't recover if already editing
    (async () => {
      const drafts = await db.entries.filter(e => e.isDraft).sortBy('created');
      if (drafts.length > 0) {
        const draft = drafts[drafts.length - 1]; // Most recent draft (sortBy is ascending)
        setBody(draft.body);
        setMood(draft.mood);
        draftIdRef.current = draft.id;
      }
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    setWordCount(body.split(/\s+/).filter(Boolean).length);
  }, [body]);

  // Auto-save draft — serialized via promise chain to prevent duplicates
  const autoSave = useCallback(async (text: string, session: number) => {
    if (text.trim().length < 10) return;
    if (isSavingRef.current) return;
    // Skip if session has changed (user clicked Done or started new entry)
    if (session !== draftSessionRef.current) return;

    if (draftIdRef.current) {
      await updateEntry(draftIdRef.current, { body: text, wordCount: text.split(/\s+/).filter(Boolean).length });
    } else {
      const draft = await saveDraft(text);
      // Re-check session after async DB operation — clean up orphan if stale
      if (session !== draftSessionRef.current) {
        await deleteEntry(draft.id).catch(() => {});
        return;
      }
      draftIdRef.current = draft.id;
    }
  }, []);

  useEffect(() => {
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    if (body.trim().length >= 10 && !activeEntryId) {
      const session = draftSessionRef.current; // Capture current session
      autoSaveTimer.current = setTimeout(() => {
        // Chain onto previous auto-save to serialize them
        autoSaveChain.current = autoSaveChain.current.then(() => autoSave(body, session)).catch(() => {});
      }, 5000);
    }
    return () => { if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current); };
  }, [body, autoSave, activeEntryId]);

  // ─── Auto-reflect after save ───────────────────────
  const runReflection = async (entryBody: string, entryId: string) => {
    setReflecting(true);
    setReflection('');
    try {
      const apiKey = await getApiKey();
      const model = await getModel();
      if (!apiKey) { setReflection('Set your API key in Settings first.'); return; }

      reflectAbortRef.current?.abort();
      reflectAbortRef.current = new AbortController();

      // Build enhanced context for reflection
      const [tasksSummary, contextMemory, recentSummaries, taskNudge] = await Promise.all([
        getTodayTasksSummary(),
        getContextMemoryPrompt(),
        getEntrySummaries(5).then(summaries => {
          const bodyPrefix = entryBody.substring(0, 80).toLowerCase();
          const filtered = summaries.filter(s => !s.toLowerCase().includes(bodyPrefix));
          return filtered.length > 0 ? filtered.slice(0, 3).join('\n') : undefined;
        }),
        getTaskNudgeSummary(),
      ]);

      const messages = getReflectionPrompt(
        entryBody,
        tasksSummary || undefined,
        contextMemory || undefined,
        recentSummaries,
        taskNudge || undefined,
      );
      let result = '';
      for await (const chunk of streamChat(messages, { apiKey, model }, reflectAbortRef.current.signal, REQUEST_CONFIG.reflect)) {
        result += chunk;
        setReflection(result);
      }
      await updateEntry(entryId, { aiReflection: result });
      await loadEntries();
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setReflection('Could not generate reflection. Check your API key and model.');
      }
    } finally {
      setReflecting(false);
    }
  };

  // ─── Save (new entry or update existing) ───────────
  const [saveError, setSaveError] = useState<string | null>(null);

  const handleSave = async () => {
    if (!body.trim() || isSavingRef.current) return;
    const saveSession = draftSessionRef.current; // Capture session before async work
    isSavingRef.current = true;
    setSaving(true);
    setSaveError(null);

    try {
      // Wait for any pending auto-save to complete first (serialized chain)
      try { await autoSaveChain.current; } catch { /* auto-save failed, continue with manual save */ }

      let entryId = activeEntryId;

      if (entryId) {
        // Updating existing entry
        await updateEntry(entryId, {
          body,
          mood,
          wordCount: body.split(/\s+/).filter(Boolean).length,
        });
        // Re-tag with updated content — use original entry's created date
        const existingEntry = await db.entries.get(entryId);
        const editEntry = { id: entryId, body, created: existingEntry?.created || new Date().toISOString(), isDraft: false, wordCount: body.split(/\s+/).filter(Boolean).length };
        // Remove old extracted tasks for this entry before re-extracting
        await db.tasks.where('entryId').equals(entryId).filter(t => t.source === 'extracted').delete();
        tagEntry(editEntry).then(async () => {
          await extractTasksFromTags(editEntry as JournalEntry);
          await loadTasks();
        }).catch(() => {});
      } else {
        // New entry
        let entry: JournalEntry;

        if (draftIdRef.current) {
          // Finalize existing draft instead of creating duplicate (#3)
          entry = await finalizeDraft(draftIdRef.current, body, mood);
          draftIdRef.current = null;
        } else {
          entry = await saveEntry(body, mood);
        }

        entryId = entry.id;
        if (mood) await logMood(mood, entry.id);
        setActiveEntryId(entryId);

        // Fire-and-forget: auto-tag, extract tasks, then refresh context
        const entryForTagging = { id: entry.id, body, created: entry.created, isDraft: false, wordCount: entry.wordCount };
        tagEntry(entryForTagging).then(async () => {
          await extractTasksFromTags(entryForTagging as JournalEntry);
          await loadTasks();
          const shouldRefresh = await shouldRefreshContext();
          if (shouldRefresh) await refreshContextMemory();
        }).catch(() => {});

        // Award achievements (#12)
        const totalEntries = (await db.entries.toArray()).filter(e => !e.isDraft).length;
        const totalWords = (await db.entries.toArray()).filter(e => !e.isDraft).reduce((s, e) => s + e.wordCount, 0);
        checkAndAwardAchievements(totalEntries, totalWords).catch(() => {});
      }

      await loadEntries();

      // Auto-reflect on save
      await runReflection(body, entryId!);

      // Only show continue if user hasn't clicked Done during save
      if (saveSession === draftSessionRef.current) {
        setShowContinue(true);
      }
    } catch (err: any) {
      setSaveError(err.message || 'Failed to save entry');
    } finally {
      isSavingRef.current = false;
      setSaving(false);
    }
  };

  // ─── Continue writing (load entry back into editor) ──
  const handleContinue = async () => {
    if (!activeEntryId) return;
    const entry = await db.entries.get(activeEntryId);
    if (entry) {
      setBody(entry.body);
      setMood(entry.mood);
      setShowContinue(false);
      setReflection('');
      setActiveEntryId(entry.id);
      textareaRef.current?.focus();
    }
  };

  // ─── Done (finish this entry) ──────────────────────
  const handleDone = () => {
    // Abort any in-flight reflection or tagging
    reflectAbortRef.current?.abort();
    savedReflectAbortRef.current?.abort();
    // Invalidate any pending auto-save callbacks
    draftSessionRef.current++;
    if (autoSaveTimer.current) clearTimeout(autoSaveTimer.current);
    setBody('');
    setMood(undefined);
    setReflection('');
    setActiveEntryId(null);
    setShowContinue(false);
    draftIdRef.current = null;
  };

  // ─── Reflect on demand (while editing) ─────────────
  const handleReflectNow = async () => {
    if (!body.trim()) return;
    setReflecting(true);
    setReflection('');
    try {
      const apiKey = await getApiKey();
      const model = await getModel();
      if (!apiKey) { setReflection('Set your API key in Settings.'); return; }

      reflectAbortRef.current?.abort();
      reflectAbortRef.current = new AbortController();

      const [tasksSummary, contextMemory, recentSummaries, taskNudge] = await Promise.all([
        getTodayTasksSummary(),
        getContextMemoryPrompt(),
        getEntrySummaries(5).then(summaries => {
          const bodyPrefix = body.substring(0, 80).toLowerCase();
          const filtered = summaries.filter(s => !s.toLowerCase().includes(bodyPrefix));
          return filtered.length > 0 ? filtered.slice(0, 3).join('\n') : undefined;
        }),
        getTaskNudgeSummary(),
      ]);
      const messages = getReflectionPrompt(body, tasksSummary || undefined, contextMemory || undefined, recentSummaries, taskNudge || undefined);
      let result = '';
      for await (const chunk of streamChat(messages, { apiKey, model }, reflectAbortRef.current.signal, REQUEST_CONFIG.reflect)) {
        result += chunk;
        setReflection(result);
      }
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setReflection('Could not generate reflection.');
      }
    } finally {
      setReflecting(false);
    }
  };

  // ─── Expand / Edit / Delete (recent entries) ───────
  const handleEditEntry = (entry: JournalEntry) => {
    setActiveEntryId(entry.id);
    setBody(entry.body);
    setMood(entry.mood);
    setReflection('');
    setShowContinue(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDelete = async (id: string) => {
    await deleteEntry(id);
    setConfirmDelete(null);
    setExpandedEntry(null);
    if (activeEntryId === id) handleDone();
    await loadEntries();
  };

  const handleReflectSaved = async (entry: JournalEntry) => {
    const id = entry.id;
    setRecentEntries(prev => prev.map(e => e.id === id ? { ...e, aiReflection: '...' } : e));
    try {
      const apiKey = await getApiKey();
      const model = await getModel();
      if (!apiKey) return;

      savedReflectAbortRef.current?.abort();
      savedReflectAbortRef.current = new AbortController();

      // For historical entries, skip today's tasks (they're unrelated)
      const [contextMemory, recentSummaries] = await Promise.all([
        getContextMemoryPrompt(),
        getEntrySummaries(5).then(summaries => {
          const filtered = summaries.filter(s => !s.includes(entry.body.substring(0, 50)));
          return filtered.length > 0 ? filtered.slice(0, 3).join('\n') : undefined;
        }),
      ]);
      const messages = getReflectionPrompt(entry.body, undefined, contextMemory || undefined, recentSummaries);
      let result = '';
      for await (const chunk of streamChat(messages, { apiKey, model }, savedReflectAbortRef.current.signal, REQUEST_CONFIG.reflect)) {
        result += chunk;
        setRecentEntries(prev => prev.map(e => e.id === id ? { ...e, aiReflection: result } : e));
      }
      await updateEntry(id, { aiReflection: result });
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setRecentEntries(prev => prev.map(e => e.id === id ? { ...e, aiReflection: 'Error.' } : e));
      }
    }
  };

  // ─── Topic suggestions ─────────────────────────────
  const handleSuggestTopics = async () => {
    setLoadingSuggestions(true);
    setShowSuggestions(true);
    try {
      const apiKey = await getApiKey();
      const model = await getModel();
      if (!apiKey) { setSuggestions(['Set your API key in Settings to get topic suggestions.']); return; }
      const recentContext = recentEntries.map(e => `[${e.created.split('T')[0]}] ${e.body.substring(0, 200)}`).join('\n');

      topicAbortRef.current?.abort();
      topicAbortRef.current = new AbortController();

      const messages = buildMessages('topic', [], 'Suggest what I should write about today.', recentContext || undefined);
      let response = '';
      for await (const chunk of streamChat(messages, { apiKey, model }, topicAbortRef.current.signal, REQUEST_CONFIG.topic_suggest)) { response += chunk; }
      const lines = response.split('\n').filter(l => l.trim());
      const parsed = lines.map(l => l.replace(/^[-•*\d.]+\s*/, '').trim()).filter(Boolean);
      setSuggestions(parsed.length > 0 ? parsed : [response]);
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        setSuggestions(['Could not generate suggestions.']);
      }
    } finally {
      setLoadingSuggestions(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      handleSave();
    }
  };

  const isEditing = !!activeEntryId;

  return (
    <div className="space-y-5 animate-fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-text-primary">
            {isEditing ? '✏️ Continue writing' : 'Journal'}
          </h1>
          <p className="text-sm text-text-muted mt-1">
            {isEditing ? 'Your entry is saved. Add more or tap Done.' : "What's on your mind?"}
          </p>
        </div>
        <button
          onClick={handleSuggestTopics}
          aria-label="Get topic suggestions"
          className="px-3 py-2 text-sm bg-bg-card border border-border rounded-xl
                     text-text-secondary hover:text-accent-amber hover:border-accent-amber
                     transition-colors"
        >
          💡 Topic
        </button>
      </div>

      {/* Topic suggestions */}
      {showSuggestions && (
        <div className="bg-bg-card border border-border rounded-xl p-4 animate-slide-up">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-accent-amber">Topic suggestions</h3>
            <button onClick={() => setShowSuggestions(false)} aria-label="Close suggestions" className="text-text-dim hover:text-text-secondary">✕</button>
          </div>
          {loadingSuggestions ? (
            <div className="text-text-muted text-sm animate-pulse-gentle">Thinking...</div>
          ) : (
            <ul className="space-y-2">
              {suggestions.map((s, i) => (
                <li key={i}>
                  <button
                    onClick={() => { setBody(prev => prev ? prev + '\n\n' + s : s); setShowSuggestions(false); }}
                    className="text-left text-sm text-text-secondary hover:text-accent-green transition-colors w-full"
                  >
                    → {s}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* ─── Today's tasks ─────────────────────────── */}
      <div className="bg-bg-card border border-border rounded-xl p-4">
        <h3 className="text-sm font-medium text-text-secondary mb-3">✅ Today's tasks</h3>

        {/* Task list */}
        {tasks.length > 0 && (
          <div className="space-y-1.5 mb-3">
            {tasks.map(task => (
              <div
                key={task.id}
                className={`flex items-center gap-2.5 px-2 py-1.5 rounded-lg cursor-pointer transition-colors ${
                  task.done ? 'opacity-50' : 'hover:bg-bg-hover'
                }`}
              >
                <input
                  type="checkbox"
                  checked={task.done}
                  onChange={async () => { await toggleTask(task.id); await loadTasks(); }}
                  aria-label={`Mark "${task.text}" as ${task.done ? 'not done' : 'done'}`}
                  className="w-4 h-4 rounded border-border text-accent-green focus:ring-accent-green"
                />
                <span className={`flex-1 text-sm ${task.done ? 'text-text-dim line-through' : 'text-text-primary'}`}>
                  {task.text}
                </span>
                <button
                  onClick={async (e) => { e.preventDefault(); await deleteTask(task.id); await loadTasks(); }}
                  className="text-text-dim hover:text-red-400 transition-colors text-xs shrink-0"
                  aria-label={`Delete task "${task.text}"`}
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Add task inline */}
        <div className="flex gap-2">
          <input
            type="text"
            value={newTaskText}
            onChange={(e) => setNewTaskText(e.target.value)}
            onKeyDown={async (e) => {
              if (e.key === 'Enter' && newTaskText.trim()) {
                e.preventDefault();
                await addTask(newTaskText.trim());
                setNewTaskText('');
                await loadTasks();
              }
            }}
            placeholder={tasks.length === 0 ? 'Add a task for today...' : 'Add another task...'}
            className="flex-1 px-3 py-2 bg-transparent text-sm text-text-primary
                       placeholder:text-text-dim focus:outline-none"
          />
          {newTaskText.trim() && (
            <button
              onClick={async () => {
                await addTask(newTaskText.trim());
                setNewTaskText('');
                await loadTasks();
              }}
              className="text-xs text-accent-green hover:text-accent-green/80 transition-colors shrink-0"
            >
              + Add
            </button>
          )}
        </div>

        {tasks.length > 0 && (
          <div className="mt-2 pt-2 border-t border-border">
            <span className="text-xs text-text-dim">
              {tasks.filter(t => t.done).length}/{tasks.length} done
            </span>
          </div>
        )}
      </div>

      {/* Editor */}
      <div className="bg-bg-card border border-border rounded-xl overflow-hidden">
        <textarea
          ref={textareaRef}
          value={body}
          onChange={(e) => setBody(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Dump your thoughts here. No judgment."
          aria-label="Journal entry"
          className="w-full min-h-[250px] p-5 bg-transparent text-text-primary
                     placeholder:text-text-dim resize-none leading-relaxed
                     focus:outline-none"
          autoFocus
        />

        <div className="px-4 py-3 border-t border-border">
          {/* Mood row */}
          <div className="flex items-center gap-1.5 mb-3">
            <span className="text-xs text-text-dim mr-1">Mood:</span>
            {MOODS.map(m => (
              <button
                key={m.value}
                onClick={() => setMood(mood === m.value ? undefined : m.value)}
                aria-label={`Mood: ${m.label}`}
                aria-pressed={mood === m.value}
                className={`text-lg transition-transform hover:scale-110 ${
                  mood === m.value ? 'scale-125 ring-2 ring-accent-green rounded-full' : 'opacity-50'
                }`}
              >
                {m.emoji}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs text-text-dim shrink-0">
              {wordCount > 0 ? `${wordCount} word${wordCount !== 1 ? 's' : ''}` : ''}
            </span>

            <div className="flex items-center gap-2">
              {isEditing && (
                <button
                  onClick={handleDone}
                  className="px-3 py-2 text-xs border border-border rounded-lg
                             text-text-secondary hover:bg-bg-hover transition-colors shrink-0"
                >
                  Done
                </button>
              )}

              <button
                onClick={handleReflectNow}
                disabled={!body.trim() || reflecting}
                className="px-3 py-2 text-xs bg-bg-secondary border border-border rounded-lg
                           text-text-secondary hover:text-accent-purple hover:border-accent-purple
                           transition-colors disabled:opacity-40 shrink-0"
              >
                {reflecting ? 'Reflecting...' : '🪞 Reflect'}
              </button>

              <button
                onClick={handleSave}
                disabled={!body.trim() || saving}
                className="px-4 py-2 text-xs bg-accent-green text-bg-primary font-medium rounded-lg
                           hover:bg-accent-green/90 transition-colors
                           disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              >
                {saving ? 'Saving...' : isEditing ? 'Update' : 'Save'}
              </button>
            </div>
            {saveError && (
              <p className="text-xs text-red-400 mt-1">{saveError}</p>
            )}
          </div>
        </div>
      </div>

      <p className="text-xs text-text-dim text-center">Ctrl+Enter to save</p>

      {/* ─── Post-save: Reflection + Continue ──────── */}
      {reflection && (
        <div className="bg-bg-card border border-accent-purple/30 rounded-xl p-5 animate-slide-up space-y-3">
          <h3 className="text-sm font-medium text-accent-purple">🪞 Reflection</h3>
          <p className="text-text-secondary text-sm leading-relaxed whitespace-pre-wrap">{reflection}</p>

          {showContinue && (
            <div className="flex items-center gap-2 pt-2 border-t border-border">
              <button
                onClick={handleContinue}
                className="px-4 py-2 text-xs bg-accent-blue/10 border border-accent-blue/30
                           text-accent-blue rounded-lg hover:bg-accent-blue/20 transition-colors"
              >
                ✏️ Continue writing
              </button>
              <button
                onClick={handleDone}
                className="px-4 py-2 text-xs bg-bg-secondary border border-border
                           text-text-secondary rounded-lg hover:bg-bg-hover transition-colors"
              >
                ✓ Done
              </button>
            </div>
          )}
        </div>
      )}

      {/* ─── Recent entries ────────────────────────── */}
      {recentEntries.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-text-muted">Recent entries</h3>
          {recentEntries.map(entry => {
            const isExpanded = expandedEntry === entry.id;
            return (
              <div key={entry.id} className="bg-bg-card border border-border rounded-xl overflow-hidden">
                <button
                  onClick={() => setExpandedEntry(isExpanded ? null : entry.id)}
                  aria-expanded={isExpanded}
                  className="w-full text-left px-4 py-3 hover:bg-bg-hover transition-colors"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-text-dim">
                      {new Date(entry.created).toLocaleDateString('en-US', {
                        weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
                      })}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-text-dim">{entry.wordCount} words</span>
                      {entry.mood && <span className="text-sm">{MOODS[entry.mood - 1]?.emoji}</span>}
                      <span className="text-text-dim text-xs">{isExpanded ? '▾' : '▸'}</span>
                    </div>
                  </div>
                  <p className="text-sm text-text-secondary mt-1 line-clamp-2">{entry.body}</p>
                </button>

                {isExpanded && (
                  <div className="px-4 pb-3 border-t border-border animate-slide-up">
                    <p className="text-sm text-text-secondary leading-relaxed mt-3 whitespace-pre-wrap">{entry.body}</p>

                    {entry.aiReflection && (
                      <div className="mt-3 p-3 bg-accent-purple/5 border border-accent-purple/20 rounded-lg">
                        <p className="text-xs text-accent-purple font-medium mb-1">🪞 Reflection</p>
                        <p className="text-xs text-text-secondary leading-relaxed">{entry.aiReflection}</p>
                      </div>
                    )}

                    <div className="flex items-center gap-2 mt-3">
                      <button
                        onClick={() => handleReflectSaved(entry)}
                        aria-label="Generate reflection for this entry"
                        className="px-3 py-1.5 text-xs bg-bg-secondary border border-border rounded-lg
                                   text-text-secondary hover:text-accent-purple hover:border-accent-purple transition-colors"
                      >
                        🪞 Reflect
                      </button>
                      <button
                        onClick={() => { handleEditEntry(entry); setExpandedEntry(null); }}
                        aria-label="Edit this entry"
                        className="px-3 py-1.5 text-xs bg-bg-secondary border border-border rounded-lg
                                   text-text-secondary hover:text-accent-blue hover:border-accent-blue transition-colors"
                      >
                        ✏️ Edit
                      </button>
                      {confirmDelete === entry.id ? (
                        <div className="flex items-center gap-1 ml-auto">
                          <button onClick={() => handleDelete(entry.id)}
                            className="px-3 py-1.5 text-xs bg-red-500/20 border border-red-500/30 rounded-lg text-red-400 hover:bg-red-500/30 transition-colors">
                            Delete
                          </button>
                          <button onClick={() => setConfirmDelete(null)}
                            className="px-3 py-1.5 text-xs border border-border rounded-lg text-text-dim hover:bg-bg-hover transition-colors">
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button onClick={() => setConfirmDelete(entry.id)}
                          aria-label="Delete this entry"
                          className="px-3 py-1.5 text-xs border border-border rounded-lg text-text-dim hover:text-red-400 hover:border-red-500/30 transition-colors ml-auto">
                          🗑️
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
